# Usage

## Required
- R version: > 4.4.1
- tinytex
  - RMarkdown でTexを使ったレンダリングを行う
- bookdown
  - https://bookdown.org/yihui/bookdown/get-started.html
  - 文書内での相互参照など

```{r}
# Rコンソールで以下を実行
install.packages(c('tinytex', 'bookdown'))
tinytex::install_tinytex()
tinytex::tlmgr_install("xetex")
```

## フォント環境
- IPA フォント
  - [IPA フォント](https://moji.or.jp/ipafont/ipa00303/) から4書体パック(Ver.003.03)を入手
  - インストールが必要のため，[ここ](https://moji.or.jp/ipafont/installation/)を参照

```{r}
# 必要であればコンソールで実行 (多分しなくていいと思う...)
tinytex::tlmgr_install("ipaex")
```

- その他フォント
  - ヒラギノやNotoなどがシステムにインストールされて使用可能な場合，`/Report/etc/_preamble.tex` から設定可

## `.Rmd` ファイルのレンダリング
`/Report/R/_compiler.r` を実行

``` {r}
getwd() # "/path/to/proj_kousen2024"
rmarkdown::render("Report/report.rmd", clean=TRUE)
```
