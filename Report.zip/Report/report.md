---
# title: "高専実習レポート"
output:
  bookdown::pdf_document2:
    toc: false
    latex_engine: xelatex
    number_sections: true
    citation_package: natbib
    keep_md: true
    extra_dependencies:
      - "float"
      - "flafter"
      - "subfig"
    includes:
      in_header: etc/_preamble.tex
bibliography: etc/ref.bib
biblio-style: unsrt
# documentclass: book
classoption:
  - a4paper,12ptj,ja=standard
---

\input{./etc/title}

\pagenumbering{roman}

\tableofcontents
\newpage

\setcounter{page}{1}
\pagenumbering{arabic}



# 実習プログラム日程 {-}

**1日目 : オリエンテーションと実験準備**

  - 11:00-12:00: 研究室紹介と実習内容の説明
  - 12:00-13:00: 昼食
  - 13:00-14:30: 心理物理実験と連続フラッシュ抑制 (CFS) 実験の理論講義
  - 14:30-17:00: 実験実施 (被験者として参加)

**2日目 : データ解析**

  - 9:30-10:30: データ解析ツールの紹介と基本操作
  - 10:30-12:00: 実験データの整形
  - 12:00-13:00: 昼食
  - 13:00-16:30: 抑制時間 (BT) の解析 (統計解析，視覚化)

**3日目 : 解析結果の考察とレポート作成**

  - 9:30-12:00: 解析結果の考察とディスカッション
  - 12:00-13:00: 昼食
  - 13:00-16:30: レポート作成 (解析手法，結果，考察)

**4日目 : プレゼンテーションの作成**

  - 9:30-12:00: プレゼンテーション準備
  - 12:00-13:00: 昼食
  - 13:00-15:00: プレゼンテーション準備
  - 15:00-16:30: フィードバック

**5日目 : プレゼンテーションとフィードバック**

  - 9:30-10:00: プレゼンテーション準備
  - 10:00-10:30: プレゼンテーション発表
  - 10:30-11:00: フィードバックと総括

\newpage

<!--
    1日目 : オリエンテーションと実験
-->
# 実習の目的
本実習は，心理物理学実験における理論と実践の両面を深く理解し，将来的な研究活動に役立てることを目的とする．

心理物理学は，人間の感覚と物理的刺激の関係を探る学問であり，正確な実験手法が求められる．
心理物理学実験の基本的な手法や注意点についての知識を学び，理論的な基礎を築く．

次に，実際の心理物理学実験を通じて，理論を実践する．
具体的には，CFS（Continuous Flash Suppression）実験を実施し，実験参加者としての体験と，実験実施者としての経験する．
これにより，実験の運営方法やデータ収集の流れを実際に体験し，実践的なスキルを習得する．

さらに，心理物理学実験の結果を適切に解釈するための基礎的な統計知識を習得する．
Rという統計用ソフトウェアを用いて，実験データの解析を行い，結果を解釈するための能力を養う．
これにより，データに基づいた科学的な結論を導くスキルを身につけ，心理物理学実験における包括的な理解を深める．

これらの学習と体験を通じて，心理物理学実験に関する理論的知識を得ることで，今後の研究などの場において役立つ基盤を構築することを目指す．

# 原理

## 連続フラッシュ抑制 (Continuous Flash Suppression: CFS)
CFS とは，短い周期で激しく変化する刺激を抑制刺激として片目に呈示した際に，もう片方の目に呈示された刺激が長時間知覚に上らなくなる現象である \cite{Tsuchiya2005}．

## bCFS (breaking Continuous Flash Suppression)
bCFS とは，CFS を用いた実験手法の一つで，CFS 下で徐々に不透明度が増加する実験対象刺激が，マスク刺激の抑制を突破して意識に上るまでの時間を計測する実験手法である \cite{Pournaghdali2020}．
この実験対象刺激が意識に上るまでの時間を抑制突破時間 (Breakthrough Time: BT) と呼び，実験対象刺激の無意識下処理における優位性の指標として用いられている．
多くのbCFS パラダイムでは，抑制突破を検出するために，実験対象刺激が画面のどこにあるのかを応答させるタスクが採用されている．
例えば，正立した顔が倒立した顔よりも早く抑制突破する場合，正立顔は倒立顔よりも無意識下で処理されやすいことが示される．

# 実験

- 顔刺激正立倒立実験を体験
- 既成データから解析・基礎的なグラフから情報量の多いグラフを作ろう！
  - t test
  - 棒グラフ
  - SE
  - raincloudみたいな
  - 刺激別の解析
- 実験データの解析は
- 論文の見かた，調べかた(できれば)
- 報告する方法を学ぶ

## 実験目的

## 実験手順

<!--
    2日目 : 実験データの解析
-->
# 統計解析

本パートでは，Rを用いて既成データの解析を行った結果を示す．
解析用データは，Michael Makoto Martinsen によってOpen Science Framework (OSF) に公開されている，Facial Ambiguity and Perception: How Face-Likeness Affects Breaking Time in Continuous Flash Suppression での実験データを用いた \cite{MichaelOSF}．

<!-- 解析ファイルの読み込み -->
<!-- part01 -->

## データの整形
本節では実験データの整形を行う．
データの整形は，統計的な解析を適切に行うことを目的に行う．



### 生データを観察する

図 \@ref(fig:plot-raw-bt) に，異常値除外前の全てのデータについてのBTの分布を示す．
図 \@ref(fig:plot-raw-bt-sub) から，参加者14、16、21、3には抑制突破されなかった多数の試行がみられる．





\begin{figure}[!h]

{\centering \includegraphics[width=0.5\linewidth,]{report_files/figure-latex/plot-raw-bt-1} 

}

\caption{breakTime の分布 (異常値除外前)}(\#fig:plot-raw-bt)
\end{figure}

\begin{figure}[!h]

{\centering \includegraphics[width=0.9\linewidth,]{report_files/figure-latex/plot-raw-bt-sub-1} 

}

\caption{参加者ごとのbreakTime の分布 (異常値除外前)}(\#fig:plot-raw-bt-sub)
\end{figure}

### リジェクトする参加者を選択する
実験での不備 (不正解の試行，15秒を超えるBTなど抑制突破が失敗した試行) を確認し，解析データから除いた．



\begin{figure}[!h]

{\centering \includegraphics[width=0.5\linewidth,]{report_files/figure-latex/plot-raw-outlierFlag-1} 

}

\caption{参加者ごとの外れ値を記録した試行数}(\#fig:plot-raw-outlierFlag)
\end{figure}

\begin{figure}[!h]

{\centering \includegraphics[width=0.5\linewidth,]{report_files/figure-latex/plot-raw-flag-1} 

}

\caption{参加者ごとの異常値を記録した試行数}(\#fig:plot-raw-flag)
\end{figure}

図 \@ref(fig:plot-raw-outlierFlag) より，参加者1人あたりの外れ値に分類された試行はそれほど多くないことがわかる．
図 \@ref(fig:plot-raw-flag) より，参加者14, 16, 3, 21, 10 には解析に使用できない試行が多いことがわかる (誤った回答，抑制突破時間が0.1秒以下15秒以上)．



ここで，試行に占める高いFlagged試行の割合 (30% 以上) の参加者は14, 16, 3, 21, 10 で，これらの参加者を解析から除外する．
この操作によって800 試行が分析から除外され，これは全ての試行 (3840 試行) の20.8333333% にあたる．

### データの保存
前処理を行ったデータを`data/processed/` フォルダに`data.csv` として保存した．



<!-- part02 -->

## BT をプロットする



はじめに，異常値を多く含んでいた実験参加者を解析するデータから除外した．



### BTの基本統計量

本節ではBTの解析を行った結果を示す．

はじめに，各実験について，条件ごとに平均値と標準誤差を算出した．
表 \@ref(tab:table_BT) に実験条件ごとの平均値と標準誤差を示す．



\begingroup
\fontsize{12.0pt}{14.4pt}\selectfont
\begin{longtable}{ccrr}
\toprule
Experiment & Orientation & Mean BT & Standard Error \\ 
\midrule\addlinespace[2.5pt]
Binary & Upright & 3.90 & 0.33 \\ 
Binary & Inverted & 4.00 & 0.32 \\ 
Gray & Upright & 3.31 & 0.28 \\ 
Gray & Inverted & 3.70 & 0.34 \\ 
\bottomrule
\end{longtable}
\endgroup

図 \@ref(fig:plot-BT) に，各実験条件について実験参加者ごとの平均値とその分布を示す．
菱形のデータポイントは平均値を，エラーバーは標準誤差を示す．

\begin{figure}[!h]

{\centering \subfloat[Gray 実験(\#fig:plot-BT-1)]{\includegraphics[width=0.5\linewidth,]{report_files/figure-latex/plot-BT-1} }\subfloat[Binary 実験(\#fig:plot-BT-2)]{\includegraphics[width=0.5\linewidth,]{report_files/figure-latex/plot-BT-2} }

}

\caption{各実験条件でのBT}(\#fig:plot-BT)
\end{figure}


<!-- part03 -->

## BT の統計的検定
本節では，各実験について，Upright 条件とInverted 条件のBTに差があるか検定を行った結果を示す．

### Binary 実験のBTの検定
本節では，Binary 実験のUpright とInverted 条件のBTについて対応ありt検定を実施した結果を示す．

はじめに，実験データの正規性の仮定を検定を行った．



シャピロ・ウィルク検定の結果，Upright 条件では正規分布に従うことが明らかとなった ($W = 0.98$, $p = .953$)．
また，Inverted 条件では正規分布に従うことが明らかとなった ($W = 0.99$, $p = .991$)．

次に，データが等分散であるか検定を行った．



ルービン検定の結果，等分散性が仮定できる ($F(1, 36) = 0.00$, $p = .997$)．

次にBinary 実験のUpright 条件とInverted 条件の2群間に差があるか対応ありt検定を行った．



対応ありt検定の結果，呈示条件間に有意な差は認められなかった ($M_D = 0.11$, 95\% CI $[-0.03, 0.25]$, $t(18) = 1.61$, $p = .125$)．

### Gray 実験のBTの検定
本節では，Gray 実験のUpright とInverted 条件のBTについて対応ありt検定を実施した結果を示す．

はじめに，実験データの正規性の仮定を検定を行った．



シャピロ・ウィルク検定の結果，Upright 条件では正規分布に従うことが明らかとなった ($W = 0.92$, $p = .129$)．
また，Inverted 条件では正規分布に従うことが明らかとなった ($W = 0.92$, $p = .120$)．

次に，データが等分散であるか検定を行った．



ルービン検定の結果，等分散性が仮定できる ($F(1, 36) = 0.20$, $p = .654$)．

次にGray 実験のUpright 条件とInverted 条件の2群間に差があるか対応ありt検定を行った．



対応ありt検定の結果，呈示条件間に有意な差が認められた ($M_D = 0.39$, 95\% CI $[0.20, 0.58]$, $t(18) = 4.22$, $p < .001$)．

<!--
    3日目
-->
# 考察

## 解析結果の考察

\newpage

# 参考文献 {-}
